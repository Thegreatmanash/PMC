# PMC
PMC stands for Pocket Mythical Creature. It's a rpg game where you have catch monsters. We are making it in gdevelop
